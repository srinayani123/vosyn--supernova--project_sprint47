#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Merge returned reviewer sheets with the keyed dataset and report:
  * per-direction / per-band score distributions (mean, median, n)
  * inter-reviewer agreement: exact and within-1 agreement rates, mean pairwise Spearman
  * items with score spread >= 3 (need adjudication)
  * a merged CSV: one row per item with all reviewer scores, median, band, origin

Usage:
    python scripts/score_analysis.py data/mandarin_judge_v1_full_KEYED.jsonl returned/*.xlsx [--out merged.csv]

Reviewer sheets may be .xlsx (sheet "Review") or .csv; columns must include item_id and a
score column (any header starting with "score").
"""
import argparse
import itertools
import json
import sys
from pathlib import Path

import pandas as pd


def load_sheet(path):
    p = Path(path)
    if p.suffix.lower() == ".xlsx":
        df = pd.read_excel(p, sheet_name="Review")
    else:
        df = pd.read_csv(p)
    score_col = next(c for c in df.columns if str(c).lower().startswith("score"))
    tag_col = next((c for c in df.columns if "tag" in str(c).lower()), None)
    out = df[["item_id", score_col]].rename(columns={score_col: "score"})
    out["score"] = pd.to_numeric(out["score"], errors="coerce")
    if tag_col:
        out["tags"] = df[tag_col].fillna("").astype(str)
    out["reviewer"] = p.stem
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("keyed_jsonl")
    ap.add_argument("sheets", nargs="+")
    ap.add_argument("--out", default="merged_scores.csv")
    args = ap.parse_args()

    key = pd.DataFrame([json.loads(l) for l in open(args.keyed_jsonl, encoding="utf-8")])
    sheets = [load_sheet(s) for s in args.sheets]
    long = pd.concat(sheets, ignore_index=True)
    missing = long[long["score"].isna()]
    if len(missing):
        print(f"WARNING: {len(missing)} blank scores", file=sys.stderr)

    wide = long.pivot_table(index="item_id", columns="reviewer", values="score")
    wide["median"] = wide.median(axis=1)
    wide["spread"] = wide.max(axis=1) - wide.min(axis=1)
    merged = key.merge(wide, left_on="item_id", right_index=True, how="left")

    print("\n== Score by direction and quality band (human median) ==")
    print(merged.groupby(["direction", "quality_band"])["median"].agg(["count", "mean", "median"]).round(2))

    print("\n== Score by candidate origin ==")
    print(merged.groupby("candidate_origin")["median"].agg(["count", "mean"]).round(2).sort_values("mean"))

    reviewers = [c for c in wide.columns if c not in ("median", "spread")]
    if len(reviewers) >= 2:
        exact, within1, rhos = [], [], []
        for a, b in itertools.combinations(reviewers, 2):
            pair = wide[[a, b]].dropna()
            exact.append((pair[a] == pair[b]).mean())
            within1.append(((pair[a] - pair[b]).abs() <= 1).mean())
            rhos.append(pair[a].corr(pair[b], method="spearman"))
        print("\n== Inter-reviewer agreement (mean over pairs) ==")
        print(f"exact agreement: {sum(exact)/len(exact):.2f}")
        print(f"within-1 agreement: {sum(within1)/len(within1):.2f}")
        print(f"Spearman rho: {sum(rhos)/len(rhos):.2f}")

    adjud = merged[merged["spread"] >= 3][["item_id", "direction", "quality_band"] + reviewers]
    print(f"\n== Items needing adjudication (spread >= 3): {len(adjud)} ==")
    if len(adjud):
        print(adjud.to_string(index=False))

    merged.to_csv(args.out, index=False, encoding="utf-8-sig")
    print(f"\nmerged file written: {args.out}")


if __name__ == "__main__":
    main()
