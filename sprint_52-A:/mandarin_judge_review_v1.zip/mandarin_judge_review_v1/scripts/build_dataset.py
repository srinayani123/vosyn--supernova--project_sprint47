#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Build the Mandarin-judge human-review dataset (v1).

Usage:
    python scripts/build_dataset.py            # writes data/*.jsonl, *.csv, *.xlsx
    python scripts/build_dataset.py --seed 7   # different shuffle / perturbation draw

Design (see docs/README.md for the full rationale):
  * Two directions: EN→ZH and ZH→EN.
  * Target per direction is read from config.json (default 100).
  * 50 unique authored source sentences per direction, each yielding exactly 2 candidates
    from different quality bands, so no reviewer sees the same source+candidate twice.
  * Quality bands (hidden from reviewers, kept in the keyed JSONL):
        1 = near-perfect      (authored reference)
        2 = good-but-imperfect (hand-written variant with a documented minor flaw)
        3 = clearly flawed    (one documented perturbation: omission / number error /
                               untranslated span / terminology error / grammar damage)
        4 = severe            (negation flip, antonym swap, hallucinated content,
                               heavy truncation, or fully untranslated source)
  * Every record carries provenance: source_origin, candidate_origin, perturbation,
    seed, build date, and the reference it was derived from.
"""
import argparse
import csv
import json
import random
import re
import sys
from datetime import date
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "scripts"))
from seed_pairs import EN_ZH, ZH_EN  # noqa: E402

BUILD_DATE = date.today().isoformat()
SOURCE_ORIGIN = "authored:claude-fable-5.1:2026-09-24"   # single authored batch, see README

# ---------------------------------------------------------------------------
# Perturbations. Each returns (new_text, note) or None if not applicable.
# ---------------------------------------------------------------------------
ZH_PUNCT_SPLIT = re.compile(r"(?<=[，；])")
EN_PUNCT_SPLIT = re.compile(r"(?<=[,;])\s*|\s+—\s+")
CN_NUM = "一二三四五六七八九"


def _split_zh(t):
    parts = [p for p in ZH_PUNCT_SPLIT.split(t) if p.strip()]
    return parts


def _split_en(t):
    return [p for p in EN_PUNCT_SPLIT.split(t) if p.strip()]


ZH_SENT_SPLIT = re.compile(r"(?<=[。！？])")
EN_SENT_SPLIT = re.compile(r"(?<=[.!?])\s+")


def omit_clause(text, lang, rng):
    parts = _split_zh(text) if lang == "zh" else _split_en(text)
    if len(parts) < 2:  # fall back to dropping a whole sentence
        parts = [x for x in (ZH_SENT_SPLIT if lang == "zh" else EN_SENT_SPLIT).split(text) if x.strip()]
    if len(parts) < 2:
        return None
    i = rng.randrange(len(parts))
    kept = parts[:i] + parts[i + 1:]
    new = "".join(kept) if lang == "zh" else " ".join(p.strip() for p in kept)
    new = re.sub(r"[，；,;]\s*$", "。" if lang == "zh" else ".", new)
    if lang == "en":
        new = new[0].upper() + new[1:]
    return new, f"omitted clause: '{parts[i].strip()}'"


def number_error(text, lang, rng):
    digits = list(re.finditer(r"\d+(?:[.,]\d+)?", text))
    if digits:
        m = rng.choice(digits)
        old = m.group(0)
        core = re.sub(r"[.,]", "", old)
        if len(core) == 1:
            new_num = str((int(core) + rng.choice([1, 2, 3])) % 10 or 7)
        else:
            # change last digit, keep format
            last = int(old[-1]) if old[-1].isdigit() else 0
            new_num = old[:-1] + str((last + rng.choice([1, 2, 3, 5])) % 10)
        new = text[:m.start()] + new_num + text[m.end():]
        return new, f"number changed: {old} -> {new_num}"
    if lang == "zh":
        cands = [(i, c) for i, c in enumerate(text) if c in CN_NUM]
        if cands:
            i, c = rng.choice(cands)
            repl = rng.choice([x for x in CN_NUM if x != c])
            return text[:i] + repl + text[i + 1:], f"number changed: {c} -> {repl}"
    else:
        words = {"one": "two", "two": "three", "three": "five", "four": "six", "five": "three",
                 "six": "eight", "seven": "nine", "eight": "six", "nine": "seven", "ten": "twelve",
                 "twenty": "thirty", "forty": "fifty", "eighteen": "sixteen"}
        found = [w for w in words if re.search(rf"\b{w}\b", text)]
        if found:
            w = rng.choice(found)
            return re.sub(rf"\b{w}\b", words[w], text, count=1), f"number changed: {w} -> {words[w]}"
    return None


def untranslated_span(text, lang, rng, source):
    """Leave the first clause of the source untranslated in place of the first target clause."""
    if lang == "zh":
        tparts, sparts = _split_zh(text), _split_en(source)
    else:
        tparts, sparts = _split_en(text), _split_zh(source)
    if len(tparts) < 2 or len(sparts) < 2:
        return None
    new_first = sparts[0].strip()
    rest = tparts[1:]
    new = new_first + ("" if lang == "zh" else " ") + ("".join(rest) if lang == "zh" else " ".join(p.strip() for p in rest))
    return new, f"first clause left untranslated: '{new_first}'"


ZH_TERM_SWAPS = {
    "令牌": "代币", "电池": "电源", "退款": "退货", "保修": "保险", "利率": "汇率", "账户": "账号",
    "实验课": "实验室", "值机": "登机", "酶": "酵母", "指示灯": "指标", "恒温器": "温度计",
    "剂量": "计量", "工作许可": "工作证", "投票率": "得票率", "供应商": "供货商", "预算": "预测",
    "轻轨": "地铁", "楼梯间": "电梯间", "标签": "商标", "微塑料": "塑料", "通胀": "通缩",
}
EN_TERM_SWAPS = {
    "exception": "error", "consent": "notice", "harness": "belt", "probation": "trial", "conductivity": "conductance",
    "subsidies": "loans", "token": "ticket", "hybrid": "online", "identification": "passport",
    "fever": "cold", "basin": "delta", "arrangement": "composition", "porpoise": "dolphin",
    "shipping": "handling", "obligations": "rights", "quarter": "month", "yuan": "dollars",
    "infrastructure": "stations", "assessed": "graded", "refrigerate": "freeze",
}


def terminology_error(text, lang, rng):
    table = ZH_TERM_SWAPS if lang == "zh" else EN_TERM_SWAPS
    found = [k for k in table if k in text]
    if not found:
        return None
    k = rng.choice(found)
    return text.replace(k, table[k], 1), f"terminology: '{k}' -> '{table[k]}'"


def grammar_damage(text, lang, rng):
    """Noticeable fluency damage (band 3): clause order broken, or agreement + article errors."""
    if lang == "en":
        new = re.sub(r"\b(the|a|an)\s", "", text, count=2)
        agree = [("is ", "are "), ("are ", "is "), ("has ", "have "), ("have ", "has "),
                 ("was ", "were "), ("were ", "was "), ("does ", "do "), ("do ", "does ")]
        rng.shuffle(agree)
        for a, b in agree:
            if a in new:
                new = new.replace(a, b, 1)
                break
        if new != text:
            return new, "grammar: articles removed / agreement broken"
        return None
    parts = _split_zh(text)
    if len(parts) >= 2:
        i = rng.randrange(len(parts) - 1)
        a, b = parts[i], parts[i + 1]
        # swap two adjacent clauses, keeping sentence-final punctuation sane
        a_core, b_core = a.rstrip("，；。"), b.rstrip("，；。")
        parts[i], parts[i + 1] = b_core + "，", a_core + ("。" if i + 1 == len(parts) - 1 else "，")
        return "".join(parts), f"grammar: clause order broken ('{a_core}' / '{b_core}')"
    return None  # single-clause zh: leave to the untranslated_word fallback


ZH_NEG_SWAPS = {"不得": "可以", "请勿": "请", "不可": "可", "没有": "有", "未能": "能够", "未遭": "已遭",
                "无法": "可以", "禁止": "允许", "不含": "包含", "不在": "在", "不适用": "适用", "不要": "要"}
EN_NEG_SWAPS = {"do not": "do", "Do not": "Do", "must not": "must", "shall not": "shall", "cannot": "can",
                "without": "with", "no cap": "a cap", "non-refundable": "refundable", "not ": "", "n't ": " "}
ZH_ANTONYMS = {"上涨": "下跌", "增长": "下降", "扩大": "缩小", "提高": "降低", "最高": "最低", "重新开放": "关闭",
               "超过": "不足", "收窄": "扩大", "延长": "缩短", "回升": "下降", "走低": "走高", "缩短": "延长",
               "以下": "以上", "之前": "之后", "免运费": "收取运费", "退款": "拒绝退款", "批准": "否决"}
EN_ANTONYMS = {"rose": "fell", "increases": "decreases", "exceeded": "fell short of", "expand": "shrink",
               "highest": "lowest", "before": "after", "extend": "shorten", "recover": "decline",
               "lower": "higher", "shorter": "longer", "rising": "falling", "approved": "rejected",
               "filled": "still open", "closes": "opens", "reopens": "closes permanently", "steady": "sharply higher"}
ZH_HALLUC = ["，并将于下周向公众公开。", "，但该决定遭到了广泛批评。", "，相关费用由政府全额承担。",
             "，预计将带来约三千个就业岗位。", "，这一做法已在多个国家推行多年。", "，详情请咨询当地办事处。",
             "，具体时间以官方网站公布为准。", "，此前已有多家媒体对此进行报道。", "，据称这是首次采用此类方案。",
             "，如有异议可在十日内提出申诉。", "，负责人表示将在年底前完成评估。", "，该消息尚未得到官方证实。"]
EN_HALLUC = [" The decision was later reversed after public backlash.", " All costs will be covered by the government.",
             " This is expected to create about 3,000 jobs.", " Similar rules have been in place in Europe for years.",
             " Details will be announced next week.", " Please contact the local office for further information.",
             " The exact schedule will be confirmed on the official website.", " Several media outlets had reported on this earlier.",
             " This is said to be the first time such an approach has been used.", " Objections may be filed within ten days.",
             " The person in charge said the assessment would be finished by year-end.", " The news has not yet been officially confirmed."]
_USED_HALLUC = set()


def negation_flip(text, lang, rng):
    table = ZH_NEG_SWAPS if lang == "zh" else EN_NEG_SWAPS
    found = [k for k in table if k in text]
    if not found:
        return None
    k = rng.choice(found)
    return text.replace(k, table[k], 1), f"negation flipped: '{k}' -> '{table[k]}'"


def antonym_swap(text, lang, rng):
    table = ZH_ANTONYMS if lang == "zh" else EN_ANTONYMS
    found = [k for k in table if re.search(rf"\b{k}\b" if lang == "en" else re.escape(k), text)]
    if not found:
        return None
    k = rng.choice(found)
    new = text.replace(k, table[k], 1)
    return new, f"meaning inverted: '{k}' -> '{table[k]}'"


def hallucination(text, lang, rng):
    pool = [h for h in (ZH_HALLUC if lang == "zh" else EN_HALLUC) if h not in _USED_HALLUC]
    if not pool:
        pool = ZH_HALLUC if lang == "zh" else EN_HALLUC
    extra = rng.choice(pool)
    _USED_HALLUC.add(extra)
    if lang == "zh":
        base = text.rstrip("。！？")
        return base + extra, f"hallucinated content appended: '{extra.strip('，')}'"
    return text + extra, f"hallucinated content appended: '{extra.strip()}'"


def truncate(text, lang, rng):
    n = len(text)
    if n < 12:
        return None
    cut = max(5, int(n * rng.uniform(0.35, 0.5)))
    head = text[:cut]
    if lang == "en" and " " in head:
        head = head[:head.rfind(" ")]
    if lang == "zh":
        m = [i for i, c in enumerate(head) if c in "，；"]
        if m and m[-1] >= 5:
            head = head[:m[-1]]
    head = head.rstrip("，,、；; 。.！!？?")
    new = head + ("。" if lang == "zh" else ".")
    return new, f"truncated at ~{int(100*cut/n)}% of reference"


def passthrough(text, lang, rng, source):
    return source, "source returned untranslated"


def untranslated_word(text, lang, rng, source):
    """Last-resort band-3 flaw for very short items: one source word left untranslated."""
    if lang == "en":
        src_core = re.sub(r"[。！？，、]", "", source)
        chunk = src_core[-2:]
        m = re.search(r"(\w+)([.!?]?)$", text)
        if not m or not chunk:
            return None
        return text[:m.start(1)] + chunk + m.group(2), f"word left untranslated: '{chunk}'"
    words = re.findall(r"[A-Za-z']+", source)
    if not words or len(text) < 4:
        return None
    w = words[-1]
    core = text.rstrip("。！？")
    return core[:-2] + w + text[len(core):], f"word left untranslated: '{w}'"


BAND3_OPS = ["omission", "number_error", "untranslated_span", "terminology_error", "grammar_damage", "untranslated_word"]
BAND4_OPS = ["negation_flip", "antonym_swap", "hallucination", "truncation", "untranslated_whole"]


def perturb(reference, source, tgt_lang, band, rng):
    ops = list(BAND3_OPS if band == 3 else BAND4_OPS)
    rng.shuffle(ops)
    for fallback in ("grammar_damage", "untranslated_word"):
        if fallback in ops:
            ops.remove(fallback); ops.append(fallback)
    for op in ops:
        if op == "omission":
            r = omit_clause(reference, tgt_lang, rng)
        elif op == "number_error":
            r = number_error(reference, tgt_lang, rng)
        elif op == "untranslated_span":
            r = untranslated_span(reference, tgt_lang, rng, source)
        elif op == "terminology_error":
            r = terminology_error(reference, tgt_lang, rng)
        elif op == "grammar_damage":
            r = grammar_damage(reference, tgt_lang, rng)
        elif op == "untranslated_word":
            r = untranslated_word(reference, tgt_lang, rng, source)
        elif op == "negation_flip":
            r = negation_flip(reference, tgt_lang, rng)
        elif op == "antonym_swap":
            r = antonym_swap(reference, tgt_lang, rng)
        elif op == "hallucination":
            r = hallucination(reference, tgt_lang, rng)
        elif op == "truncation":
            r = truncate(reference, tgt_lang, rng)
        elif op == "untranslated_whole":
            # keep rare: only when the draw says so (~1 in 4 attempts) to avoid over-representation
            r = passthrough(reference, tgt_lang, rng, source) if rng.random() < 0.25 else None
        else:
            r = None
        if r and r[0] != reference:
            return op, r[0], r[1]
    raise RuntimeError(f"No applicable perturbation for band {band}: {reference}")


# ---------------------------------------------------------------------------
# Assignment: 50 sources -> 100 candidates per direction with the target band mix
# ---------------------------------------------------------------------------
def band_plan(n_sources, n_with_imperfect, mix, rng):
    """Return list of (source_idx, band) pairs of length 2*n_sources."""
    assert n_with_imperfect <= n_sources
    total = 2 * n_sources
    counts = {b: round(total * mix[str(b)]) for b in (1, 2, 3, 4)}
    counts[2] = min(counts[2], n_with_imperfect)
    # fix rounding so bands sum to total
    diff = total - sum(counts.values())
    counts[3] += diff
    plan = []
    # sources with an authored imperfect variant get band 2 once
    b2_sources = list(range(n_with_imperfect))
    rng.shuffle(b2_sources)
    for s in b2_sources[:counts[2]]:
        plan.append((s, 2))
    # remaining slots come from bands 1, 3, 4
    slots = {s: 2 - sum(1 for p in plan if p[0] == s) for s in range(n_sources)}
    remaining = {1: counts[1], 3: counts[3], 4: counts[4]}
    two_slot = [s for s in range(n_sources) if slots[s] == 2]
    one_slot = [s for s in range(n_sources) if slots[s] == 1]
    rng.shuffle(two_slot)
    rng.shuffle(one_slot)
    # two-slot sources: always take the two most abundant distinct bands (keeps it feasible)
    for s in two_slot:
        order = sorted(remaining, key=lambda b: (-remaining[b], rng.random()))
        b1, b2 = order[0], order[1]
        if remaining[b2] == 0:
            raise RuntimeError("could not assign distinct bands; adjust mix")
        remaining[b1] -= 1
        remaining[b2] -= 1
        plan += [(s, b1), (s, b2)]
    pool = [b for b, c in remaining.items() for _ in range(c)]
    rng.shuffle(pool)
    assert len(pool) == len(one_slot), (len(pool), len(one_slot))
    for s, b in zip(one_slot, pool):
        plan.append((s, b))
    return plan


def build_direction(pairs, direction, src_lang, tgt_lang, mix, rng):
    n_imp = sum(1 for p in pairs if p[3])
    plan = band_plan(len(pairs), n_imp, mix, rng)
    records = []
    for s_idx, band in plan:
        domain, source, reference, imperfect, flaw_note = pairs[s_idx]
        src_id = f"{direction}-S{s_idx+1:03d}"
        rec = {
            "direction": direction,
            "source_id": src_id,
            "domain": domain,
            "source_text": source,
            "reference_translation": reference,
            "quality_band": band,
            "source_origin": SOURCE_ORIGIN,
            "source_ref": f"scripts/seed_pairs.py::{'EN_ZH' if direction=='EN-ZH' else 'ZH_EN'}[{s_idx}]",
            "license": "internal; authored for this task, no third-party text",
        }
        if band == 1:
            rec.update(candidate_translation=reference, candidate_origin="reference:authored",
                       perturbation=None, flaw_note="none (reference)")
        elif band == 2:
            rec.update(candidate_translation=imperfect, candidate_origin="authored_imperfect",
                       perturbation=None, flaw_note=flaw_note)
        else:
            op, text, note = perturb(reference, source, tgt_lang, band, rng)
            rec.update(candidate_translation=text, candidate_origin=f"perturbed_reference:{op}",
                       perturbation=op, flaw_note=note)
        records.append(rec)
    return records


def write_outputs(records, out_dir, seed):
    out_dir.mkdir(parents=True, exist_ok=True)
    # opaque, shuffled item ids so band cannot be inferred from ordering
    rng = random.Random(seed + 1000)
    rng.shuffle(records)
    counters = {"EN-ZH": 0, "ZH-EN": 0}
    for r in records:
        counters[r["direction"]] += 1
        prefix = "EZ" if r["direction"] == "EN-ZH" else "ZE"
        r["item_id"] = f"MJ-{prefix}-{counters[r['direction']]:04d}"
        r["build_seed"] = seed
        r["build_date"] = BUILD_DATE
        r["batch"] = "v1"

    # 1) keyed JSONL (internal only)
    with open(out_dir / "mandarin_judge_v1_full_KEYED.jsonl", "w", encoding="utf-8") as f:
        for r in sorted(records, key=lambda x: x["item_id"]):
            f.write(json.dumps(r, ensure_ascii=False) + "\n")

    # 2) blind CSV for reviewers
    blind_cols = ["item_id", "direction", "source_text", "candidate_translation",
                  "score_1_to_5", "error_tags", "comment"]
    rows = sorted(records, key=lambda x: x["item_id"])
    with open(out_dir / "reviewer_sheet_v1_BLIND.csv", "w", encoding="utf-8-sig", newline="") as f:
        w = csv.writer(f)
        w.writerow(blind_cols)
        for r in rows:
            w.writerow([r["item_id"], r["direction"].replace("-", "→"), r["source_text"],
                        r["candidate_translation"], "", "", ""])

    # 3) blind XLSX with dropdowns
    try:
        from openpyxl import Workbook
        from openpyxl.styles import Alignment, Font, PatternFill
        from openpyxl.worksheet.datavalidation import DataValidation
        wb = Workbook()
        ws = wb.active
        ws.title = "Review"
        hdr = ["item_id", "direction", "source_text", "candidate_translation",
               "score (1-5)", "error_tags", "comment (optional)"]
        ws.append(hdr)
        for c in ws[1]:
            c.font = Font(name="Arial", bold=True)
            c.fill = PatternFill("solid", fgColor="DDDDDD")
        for r in rows:
            ws.append([r["item_id"], r["direction"].replace("-", "→"), r["source_text"],
                       r["candidate_translation"], None, None, None])
        n = len(rows) + 1
        dv = DataValidation(type="list", formula1='"1,2,3,4,5"', allow_blank=True,
                            showErrorMessage=True, errorTitle="Score", error="Enter a whole number 1–5")
        ws.add_data_validation(dv)
        dv.add(f"E2:E{n}")
        widths = {"A": 14, "B": 10, "C": 60, "D": 60, "E": 11, "F": 28, "G": 40}
        for col, wdt in widths.items():
            ws.column_dimensions[col].width = wdt
        for row in ws.iter_rows(min_row=2, max_row=n):
            for c in row:
                c.font = Font(name="Arial")
                c.alignment = Alignment(wrap_text=True, vertical="top")
            row[4].fill = PatternFill("solid", fgColor="FFFF99")
            row[5].fill = PatternFill("solid", fgColor="FFFF99")
            row[6].fill = PatternFill("solid", fgColor="FFFF99")
        ws.freeze_panes = "C2"

        legend = wb.create_sheet("Legend")
        legend_rows = [
            ["Fill in the three yellow columns on the Review sheet: score (1-5), error_tags, comment."],
            ["Do not edit item_id, direction, source_text or candidate_translation."],
            [""],
            ["error_tags: separate with ; from this list ->",
             "ACC (mistranslation) ; OMIT (omission) ; ADD (invented content) ; TERM (terminology) ; FLU (grammar/fluency) ; REG (register/tone) ; UNTR (untranslated) ; NUM (number/date/unit)"],
            [""],
            ["Example row (format only, not a real item):"],
            ["MJ-XX-0000", "EN→ZH", "The store opens at 9 a.m.", "商店上午9点开门。", 5, "", ""],
            ["MJ-XX-0000", "ZH→EN", "禁止吸烟。", "Smoking is allowed.", 1, "ACC", "meaning inverted"],
            [""],
            ["Full rubric and anchors: docs/reviewer_instructions.md"],
        ]
        for lr in legend_rows:
            legend.append(lr)
        for row in legend.iter_rows():
            for c in row:
                c.font = Font(name="Arial")
        legend.column_dimensions["A"].width = 44
        legend.column_dimensions["B"].width = 110
        wb.save(out_dir / "reviewer_sheet_v1_BLIND.xlsx")
    except ImportError:
        print("openpyxl not available; skipped xlsx", file=sys.stderr)

    # 4) stats
    stats = {}
    for r in records:
        d = stats.setdefault(r["direction"], {"total": 0, "bands": {}, "perturbations": {}, "domains": {}})
        d["total"] += 1
        d["bands"][r["quality_band"]] = d["bands"].get(r["quality_band"], 0) + 1
        if r["perturbation"]:
            d["perturbations"][r["perturbation"]] = d["perturbations"].get(r["perturbation"], 0) + 1
        d["domains"][r["domain"]] = d["domains"].get(r["domain"], 0) + 1
    with open(out_dir / "build_stats.json", "w", encoding="utf-8") as f:
        json.dump({"build_date": BUILD_DATE, "seed": seed, "directions": stats}, f, ensure_ascii=False, indent=2)
    return stats


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--seed", type=int, default=None)
    ap.add_argument("--out", default=str(ROOT / "data"))
    args = ap.parse_args()
    cfg = json.loads((ROOT / "config.json").read_text(encoding="utf-8"))
    seed = args.seed if args.seed is not None else cfg["seed"]
    rng = random.Random(seed)
    mix = cfg["quality_band_mix"]

    for name, pairs in (("EN_ZH", EN_ZH), ("ZH_EN", ZH_EN)):
        assert len(pairs) * 2 == cfg["target_per_direction"], \
            f"{name}: {len(pairs)} sources x2 != target {cfg['target_per_direction']}"

    records = build_direction(EN_ZH, "EN-ZH", "en", "zh", mix, rng)
    records += build_direction(ZH_EN, "ZH-EN", "zh", "en", mix, rng)

    # sanity: no duplicate (source, candidate) and no empty candidates
    seen = set()
    for r in records:
        key = (r["source_text"], r["candidate_translation"])
        assert key not in seen, f"duplicate candidate for source: {r['source_text'][:30]}"
        assert r["candidate_translation"].strip(), "empty candidate"
        seen.add(key)

    stats = write_outputs(records, Path(args.out), seed)
    print(json.dumps(stats, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
