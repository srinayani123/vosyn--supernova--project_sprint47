# Task breakdown — Mandarin judge human-review dataset

User story: As a team, we want to create a Mandarin dataset that can be sent out for human review, so we can get fresh, trustworthy labels for the Mandarin judge.

Status key: ✅ done in this package · 🔲 to do · 👤 needs a human decision

| # | Subtask | Acceptance criterion served | Output | Status |
|---|---|---|---|---|
| 1 | Set targets: items per direction, reviewers per item, band mix, Chinese variant | Target set upfront | `config.json` | ✅ (100/direction, 3 reviewers, 25/35/25/15) |
| 2 | Author or source 50 independent source sentences per direction across domains and lengths | Independent sourcing | `scripts/seed_pairs.py` | ✅ authored; 🔲 corpus slice for v2 (see README "Sourcing statement") |
| 3 | Write reference translations for every source | Quality range (band 1) | `seed_pairs.py` | ✅ |
| 4 | Hand-write good-but-imperfect variants with documented flaws for 35 sources per direction | Quality range (band 2) | `seed_pairs.py` | ✅ |
| 5 | Implement documented perturbations for flawed and severe bands; make the build reproducible | Quality range (bands 3–4), traceability | `scripts/build_dataset.py` | ✅ |
| 6 | Define the provenance schema and populate it on every record | Traceability | keyed JSONL, README schema table | ✅ |
| 7 | Produce blind reviewer sheet (no bands, shuffled, opaque IDs) with score dropdown and legend | Packaging | `data/reviewer_sheet_v1_BLIND.xlsx/.csv` | ✅ |
| 8 | Write rubric + instructions + calibration set | Packaging / no-clarification rubric | `docs/reviewer_instructions.md` | ✅ |
| 9 | Native-speaker review of the seed pairs (references and imperfect variants) before sending out | Trustworthy labels | sign-off comment in `seed_pairs.py` header | 👤 recommended: one native ZH and one native EN speaker skim the 100 pairs (~1 h) |
| 10 | Pilot: 2 people rate 20 items + calibration set; check instructions raise no questions; adjust wording | Rubric usable without clarification | pilot notes | 🔲 |
| 11 | Recruit 3 reviewers per direction; confirm language qualifications and availability | Trustworthy labels | reviewer roster | 👤 |
| 12 | Send package; collect returned sheets; run `score_analysis.py`; adjudicate spans ≥3 | Labels | `returned/`, analysis output | 🔲 |
| 13 | Compare judge scores with human medians per band and per direction; report correlation and where the judge diverges | Story goal | analysis notebook / short report | 🔲 |
| 14 | v2: add corpus-sourced and real-model-output slices using the same schema | Independence + realism | seed loader | 🔲 |

## Definition of done for the story

- 200 blind items (100 per direction) delivered to reviewers with instructions and calibration set.
- Every item traceable to its source and to how its candidate was produced.
- Three independent ratings per item returned; adjudication done for high-spread items.
- Per-band human score distributions look sane (band 1 median ≥4, band 4 median ≤2); if not, the instructions or seed data are revised before the labels are used.
- Judge-vs-human comparison produced from `score_analysis.py` output.

## Estimated effort

| Step | Effort |
|---|---|
| Native-speaker skim of seed pairs (step 9) | 1 h × 2 people |
| Pilot (step 10) | 1 h × 2 people + 0.5 h edits |
| Full review (step 12) | ~3.5 h × 3 reviewers per direction (each rates 200 items) |
| Analysis (steps 12–13) | 2–3 h |
