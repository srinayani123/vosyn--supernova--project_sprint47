# Mandarin Translation Quality Review — Reviewer Instructions (v1)

You are rating the quality of machine-produced translations between English and Simplified Chinese. Your scores will be used as ground truth to check an automated quality judge, so please rate what is actually on the page, not what you think the system "meant".

Time budget: about 200 items, roughly 45–60 seconds each. Plan for 3–4 hours including the calibration set. You may split the work across sessions.

## 1. What you will see

Each row in the review sheet has:

| Column | What it is |
|---|---|
| `item_id` | Identifier. Do not change. |
| `direction` | `EN→ZH` (English source, Chinese translation) or `ZH→EN` (Chinese source, English translation). |
| `source_text` | The original sentence. Treat it as correct even if you would have written it differently. |
| `candidate_translation` | The translation you are rating. |
| `score (1-5)` | **You fill this in.** One whole number. Required. |
| `error_tags` | **You fill this in.** Zero or more tags from the list in §4, separated by `;`. Required for any score of 3 or below. |
| `comment` | Optional. A few words on anything the tags don't capture. |

Items are in random order. Some sources appear twice with different translations — rate each translation on its own.

## 2. The one question you are answering

**If this translation were handed to a reader who needs the source's meaning, how well would it serve them?**

Weigh accuracy first, then fluency, then style/register. A fluent sentence that says the wrong thing is worse than a clumsy sentence that says the right thing.

## 3. Score scale

| Score | Label | Use it when… |
|---|---|---|
| **5** | Publishable | Meaning is complete and exact. Reads as if written natively in the target language for this genre. You would change nothing, or at most a comma. |
| **4** | Minor polish | Meaning is complete and exact. One or two small issues a careful editor would tweak — slightly stiff wording, a register that is a touch off (e.g. 你 where 您 fits), a less-than-ideal term that is still understood correctly. Nothing that changes what the reader learns. |
| **3** | Usable with edits | The reader gets the right overall meaning, but the text is clearly a translation and needs real editing: calques, wrong-but-guessable terminology, grammar errors, an untranslated word, a dropped detail that does not change the main point, a number/unit written unnaturally but correctly. |
| **2** | Misleading | The reader would take away something wrong or incomplete: a factual error (wrong number, wrong date, wrong actor), an omitted clause that changes the point, an idiom translated so literally it doesn't make sense, a whole segment left untranslated. The topic is still recognisable. |
| **1** | Unusable | Meaning inverted or lost; content invented that is not in the source; the output is cut off mid-sentence; the source is returned untranslated; or the text is nonsense. Also use 1 for any error that would cause harm if acted on (medication, safety, legal obligations), even if the rest is fine. |

Tie-breakers:

- Between 4 and 3: would a reader *notice* it was translated? Noticeable → 3.
- Between 3 and 2: does the reader come away with a *wrong fact*? Wrong fact → 2.
- Between 2 and 1: is the wrong fact the *opposite* of the source, or invented from nothing, or is the output structurally broken? Yes → 1.
- A single severe error caps the score at 2, regardless of how good the rest is. A single meaning inversion or invented fact caps it at 1.

## 4. Error tags

Add every tag that applies. Tags are diagnostic; the score is your overall judgment.

| Tag | Meaning | Example |
|---|---|---|
| `ACC` | Mistranslation — a word/phrase means something different from the source | "fell 8%" → 增长8% |
| `OMIT` | Something in the source is missing from the translation | source has two conditions, translation has one |
| `ADD` | Something in the translation is not in the source | an extra sentence about costs |
| `TERM` | Wrong or non-standard terminology for the domain | 剂量 → 计量; "safety harness" → "safety belt" |
| `FLU` | Grammar, word order, unnatural phrasing, sentence fragments | "the assessment is qualified, formally hired." |
| `REG` | Register or tone mismatch (formal/informal, marketing punch lost, chat message made stiff) | 你 in a legal notice; hype line rendered flatly |
| `UNTR` | Untranslated source text left in the output (a word, a clause, or everything) | "Caution: wet 地滑." |
| `NUM` | Number, date, unit, currency or measurement error or unnatural rendering | 3.8十亿 instead of 38亿; 24 hours → 29 hours |

`NUM` covers both wrong numbers (usually score 2) and correct-but-unnatural numbers (usually score 3). Say which in the comment if it's not obvious.

## 5. Rules of thumb

1. **Score the translation, not the source.** If the source is awkward, ambiguous, or has a typo, judge whether the translation is a reasonable rendering of it.
2. **Do not reward length.** Adding explanation that isn't in the source is `ADD`, not a bonus.
3. **Idioms:** a natural target-language equivalent is fine (5). A literal rendering that a native reader wouldn't understand is `ACC` + `FLU` and usually 2.
4. **Names and acronyms:** established Chinese forms are expected (Tsinghua, 联合国教科文组织). Leaving a name in Latin script in a Chinese sentence is `UNTR`; a non-standard romanisation of a Chinese name in English is `TERM`.
5. **Regional variants:** the expected variety is Simplified Chinese with mainland-China usage. Taiwan/HK terms that are understood on the mainland are at most `REG`, not `ACC`.
6. **Truncated or empty-looking output** is 1, tagged `OMIT`.
7. **Source returned untranslated** is 1, tagged `UNTR`.
8. **Safety-critical content** (medicine, warnings, legal obligations): any error that changes what the reader should do is 1.
9. **Don't over-think 4 vs 5.** If you'd ship it as-is, it's a 5.
10. **Don't look up answers or use MT/AI tools.** We want your independent judgment.

## 6. Before you start: calibration set

Rate these ten items yourself **before** reading the gold scores. If you disagree with a gold score by 2 or more, re-read §3 and note the item in your first comment field so we can discuss.

| # | Dir | Source | Candidate | Your score |
|---|---|---|---|---|
| C1 | EN→ZH | The meeting has been moved to 3 p.m. on Thursday. | 会议已改到周四下午3点。 | |
| C2 | EN→ZH | Please submit your expense report by the 15th of each month. | 请在每个月15号之前提交你的报销单。 | |
| C3 | EN→ZH | The device automatically shuts off after ten minutes of inactivity. | 该装置在十分钟不活动之后自动关机。 | |
| C4 | EN→ZH | Sales fell 8% in the second quarter, the first decline in three years. | 第二季度销售额增长8%，是三年来首次。 | |
| C5 | EN→ZH | Do not take this medication with alcohol. | 本药可与酒精同服。 | |
| C6 | ZH→EN | 会议室已预订到下午五点。 | The meeting room is booked until 5 p.m. | |
| C7 | ZH→EN | 请于本周五前将合同签字后寄回。 | Please sign the contract and mail it back before this Friday. | |
| C8 | ZH→EN | 他这个人说话不太靠谱，你别全信。 | This person's speech is not very reliable, don't fully believe. | |
| C9 | ZH→EN | 由于天气原因，航班延误约两小时。 | Due to the weather, the flight was cancelled. | |
| C10 | ZH→EN | 禁止携带宠物进入本商场。 | Pets are welcome in this mall, and there is free parking on level 2. | |

<details>
<summary>Gold scores and rationale (open after you have rated all ten)</summary>

| # | Gold | Tags | Why |
|---|---|---|---|
| C1 | 5 | — | Complete, accurate, natural. |
| C2 | 4 | REG | Accurate and natural; only nit is 你 where 您 fits a workplace notice. |
| C3 | 3 | FLU, TERM | Meaning fully recoverable, but 不活动 is a calque and 装置 is stiff; obviously translated. |
| C4 | 2 | ACC, OMIT | "fell" became 增长 — the reader gets the wrong fact. 下降 dropped. |
| C5 | 1 | ACC | Says the opposite in a safety-critical context. |
| C6 | 5 | — | Complete, accurate, natural. |
| C7 | 4 | FLU | "by this Friday" would be more idiomatic than "before". Minor polish. |
| C8 | 3 | FLU | Meaning comes through; "this person's speech" unnatural; last clause is a fragment. |
| C9 | 2 | ACC, OMIT | "delayed about two hours" became "cancelled" — factual error plus omission, topic still recognisable. |
| C10 | 1 | ACC, ADD | Meaning inverted and content invented. |

</details>

## 7. When you're done

- Every row has a score. Rows scored 1–3 have at least one tag.
- Save the file with your name or reviewer ID in the filename, e.g. `reviewer_sheet_v1_R2.xlsx`.
- If anything in the sheet was unclear, tell us which `item_id`s — that feedback improves the next batch.

Thank you.
