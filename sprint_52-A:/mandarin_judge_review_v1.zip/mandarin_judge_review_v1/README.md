# Mandarin Judge — Human Review Dataset v1

Fresh, independently sourced examples for human labelling, to obtain trustworthy ground-truth scores for the Mandarin translation-quality judge.

Built 2026-09-24. Seed `20260924`. Reproducible with `python scripts/build_dataset.py`.

## Acceptance criteria → how they are met

| Criterion | Implementation |
|---|---|
| Additional examples per direction, sourced independently of the borrowed data | 100 items per direction (EN→ZH, ZH→EN), 200 total. Every source sentence, reference and hand-written flawed variant was **authored fresh for this task** (`scripts/seed_pairs.py`). Nothing is copied from the borrowed set or from any public corpus, so there is zero overlap by construction. See "Sourcing" for the trade-off and the path to add corpus-sourced items. |
| Span a range of quality levels | Four hidden quality bands with a fixed mix: 25% near-perfect, 35% good-but-imperfect, 25% clearly flawed, 15% severe. Flawed/severe items come from documented perturbations of the reference (omission, number error, untranslated span, terminology error, grammar damage, negation flip, antonym swap, hallucination, truncation, untranslated source). |
| Record where each example came from | Every record in the keyed JSONL carries `source_origin`, `source_ref` (file + index), `candidate_origin`, `perturbation`, `flaw_note`, `reference_translation`, `build_seed`, `build_date`, `batch`, `license`. |
| Target per direction set upfront | `config.json`: `target_per_direction: 100`, `reviewers_per_item: 3`, band mix, Chinese variant. The builder asserts the seed set matches the target. |
| Package with scoring instructions and a rubric usable without clarification | `docs/reviewer_instructions.md`: single question, 5-point anchored scale with tie-breakers, 8 error tags with examples, rules of thumb, a 10-item calibration set with gold scores and rationale, and completion checklist. The blind XLSX has a score dropdown and a Legend sheet. |

## Contents

```
config.json                              targets and band mix (edit here, then rebuild)
README.md                                this file
data/
  reviewer_sheet_v1_BLIND.xlsx           send this to reviewers (score dropdown, legend sheet)
  reviewer_sheet_v1_BLIND.csv            same content, UTF-8 CSV
  mandarin_judge_v1_full_KEYED.jsonl     INTERNAL ONLY — includes bands, references, flaw notes
  build_stats.json                       counts per direction / band / perturbation / domain
docs/
  reviewer_instructions.md               send this with the sheet
  task_breakdown.md                      subtasks, owners, definition of done
scripts/
  seed_pairs.py                          authored sources, references, imperfect variants, calibration items
  build_dataset.py                       band assignment + perturbations + output writers
  score_analysis.py                      merge returned sheets with the key; agreement + per-band stats
```

**Do not send `mandarin_judge_v1_full_KEYED.jsonl` to reviewers.** It contains the answer key.

## Dataset design

- **Directions:** EN→ZH and ZH→EN, 100 items each.
- **Sources:** 50 unique authored sentences per direction across ~40 domains (news, business email, software, medical, legal, casual chat, marketing, public notices, literary, support, idioms, numbers, names, long sentences, one-line signs, questions, instructions, finance, education, travel, HR, science, social media, safety, recipes, e-commerce, politics, sports, weather, real estate, philosophy, parenting, music, environment, …). Lengths range from 3 words to ~40.
- **Candidates:** each source yields exactly two candidates from different bands, so 100 items/direction. Reviewers therefore see some sources twice; the instructions tell them to rate each translation independently.
- **Chinese variant:** Simplified, mainland-China conventions (stated in the instructions so Taiwan/HK usage is scored as register, not accuracy).

### Quality bands (hidden from reviewers)

| Band | Share | Origin | Expected human score |
|---|---|---|---|
| 1 near-perfect | 25% | authored reference | 5 (occasionally 4) |
| 2 good-but-imperfect | 35% | hand-written variant with one documented minor flaw (`flaw_note`) | 3–4 |
| 3 clearly flawed | 25% | one perturbation of the reference: omission / number / untranslated span or word / terminology / grammar | 2–3 |
| 4 severe | 15% | negation flip / antonym swap / hallucinated sentence / truncation / source returned untranslated | 1–2 |

Band 2 is the largest because it is where a judge most often disagrees with humans; bands 3–4 exist so the judge's low end is also checked. The expected-score column is a sanity range, not a target: reviewers are blind to it, and disagreement with it is information, not error.

## Sourcing statement (read this)

All text was authored by Claude (Fable 5.1) on 2026-09-24 specifically for this task. This guarantees independence from the borrowed data and gives clean licensing, and it let us control domain, length and flaw type precisely.

The trade-off: authored sentences are cleaner and more "typical" than naturally occurring text. Recommended follow-up for v2, so the set is not only synthetic:

1. Add a corpus-sourced slice (target: 50 per direction) from parallel data not used in the borrowed set — recent WMT news test sets, FLORES-200 devtest, OPUS subtitles for colloquial register — recording `source_origin` as `corpus:<name>:<version>` and `source_ref` as the line/segment ID, and checking the license before use.
2. Add real model output (target: 50 per direction) as band-2/3 candidates, recording `candidate_origin` as `model:<name>:<version>:<date>` so judge-vs-human results can be broken down by producing system.

The schema already accommodates both; only `seed_pairs.py`/a loader needs extending.

## Record schema (`mandarin_judge_v1_full_KEYED.jsonl`)

| Field | Meaning |
|---|---|
| `item_id` | `MJ-EZ-0001` … / `MJ-ZE-0001` …, assigned after shuffling so order carries no band signal |
| `direction` | `EN-ZH` or `ZH-EN` |
| `source_id` | `EN-ZH-S001` … stable ID of the source sentence |
| `domain` | content domain label |
| `source_text` | the source |
| `candidate_translation` | what reviewers rate |
| `reference_translation` | authored reference (hidden) |
| `quality_band` | 1–4 (hidden) |
| `source_origin` | `authored:claude-fable-5.1:2026-09-24` (or `corpus:…` in future batches) |
| `source_ref` | file + index of the seed entry |
| `candidate_origin` | `reference:authored` / `authored_imperfect` / `perturbed_reference:<op>` |
| `perturbation` | op name or null |
| `flaw_note` | human-readable description of the intended flaw |
| `license` | usage terms of the text |
| `batch`, `build_seed`, `build_date` | provenance of the build |

## Reviewer workflow

1. Send `docs/reviewer_instructions.md` and `data/reviewer_sheet_v1_BLIND.xlsx` to each of 3 reviewers (bilingual, native or near-native in the target language of at least one direction; ideally at least one reviewer per direction whose native language is the target).
2. Reviewers complete the 10-item calibration set first and flag any ≥2-point disagreement with gold.
3. Reviewers return a filled sheet each (`reviewer_sheet_v1_R1.xlsx`, `_R2`, `_R3`).
4. Run `python scripts/score_analysis.py data/mandarin_judge_v1_full_KEYED.jsonl returned/*.xlsx` to get per-band score distributions, exact/adjacent agreement, and a merged file ready for judge comparison.

Adjudication rule: if the three scores span ≥3 points (e.g. 1, 2, 4), a fourth reviewer or the task owner adjudicates; otherwise use the median.

## Rebuilding / extending

- Change targets or mix in `config.json`, then `python scripts/build_dataset.py`. The builder asserts `2 × sources == target` per direction, so adding target means adding seed pairs.
- Different perturbation draw: `python scripts/build_dataset.py --seed 7`.
- Add sources: append tuples to `EN_ZH` / `ZH_EN` in `scripts/seed_pairs.py`; give the first N a hand-written imperfect variant if you want them eligible for band 2.
